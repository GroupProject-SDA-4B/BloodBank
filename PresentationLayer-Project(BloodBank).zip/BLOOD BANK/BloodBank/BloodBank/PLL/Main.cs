﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
namespace BloodBank.PLL
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            load.Width += 2;
            timer1.Start();
            if (load.Width >= 656)
            {
                timer1.Stop();
                Login newForm = new Login();
                newForm.Show();
                this.Hide();

            }
        }
    }
}
