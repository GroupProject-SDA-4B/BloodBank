﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace BloodBank.PLL
{
    public partial class Search_Donors : Form
    {
        public Search_Donors()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void profile1_Click(object sender, EventArgs e)
        {
            if (textboxUser.Text == "" && textboxPassword.Text == "")
            {
                MessageBox.Show("Please Fill Both Fields");
            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-CCBV35A\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True");
                string query = "select * from registration where BloodGroup ='" + textboxUser.Text.Trim() + "' and City ='" + textboxPassword.Text.Trim() + " ' ";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dtbl = new DataTable();
                sda.Fill(dtbl);
                //SqlCommand cmd = new SqlCommand("Select UserName= @UserName and Password = @Password from Registration");
                //con.Open();
                //cmd.Parameters.AddWithValue("@UserName" , textboxUser.Text);
                //cmd.Parameters.AddWithValue("@Password", textboxPassword.Text);
                //cmd.Connection = con;
                //cmd.CommandText = ("Select UserName= @UserName and Password = @Password from Registeration");
                //SqlDataReader dr = cmd.ExecuteReader();
                if (dtbl.Rows.Count == 1)
                {
                    //
                    //MessageBox.Show("LOGIN SUCCESSFUL");
                    DonorsList p = new DonorsList();
                    this.Hide();
                    p.Show();


                }
                else
                {
                    MessageBox.Show("INVALID SEARCH");
                }
            }
        }
    }
}
