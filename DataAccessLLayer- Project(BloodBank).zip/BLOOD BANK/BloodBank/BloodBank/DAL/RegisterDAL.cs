﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace BloodBank.DAL
{
    public class RegisterDAL
    {
        DataTable dt = new DataTable();
        
        public  DataTable ReadRegister()
        {
            Connection conn = new Connection();
            if (ConnectionState.Closed == conn.sqlcon.State)
            {
                conn.sqlcon.Open();
            }

            SqlCommand cmd = new SqlCommand("Select * From Registration", conn.sqlcon);
            try
            {
                SqlDataReader rd = cmd.ExecuteReader();
                dt.Load(rd);
                return dt;
            }
            catch
            {

                throw;
            }
        }
    }
}
