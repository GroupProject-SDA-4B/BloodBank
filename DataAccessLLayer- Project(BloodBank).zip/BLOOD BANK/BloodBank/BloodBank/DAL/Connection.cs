﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace BloodBank.DAL
{
    public class Connection
    {
        public SqlConnection sqlcon = new SqlConnection("Data Source=.;Integrated Security=True");
    }
}