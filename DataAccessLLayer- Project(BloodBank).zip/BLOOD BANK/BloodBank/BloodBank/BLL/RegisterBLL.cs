﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using BloodBank.DAL;

namespace BloodBank.BLL
{
    public class RegisterBLL
    {
        //public void InsertUser(int _ID, string _FirstName, string _LastName, string _UserName, string _Password, string _BloodGroup, string _Gender, int _Age, string _ContactNo, string _Address, string _Area, string _City)
        //{

        //}
        public DataTable GetRegistration()
        {
            try
            {
                RegisterDAL objDAl = new RegisterDAL();
                return objDAl.ReadRegister();
            }
            catch
            {

                throw;
            }
        }
    }
}
