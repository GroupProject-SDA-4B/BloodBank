﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using BloodBank.BLL;
namespace BloodBank.PLL
{
    public partial class Login : Form
    {
        //SqlConnection con = new SqlConnection();
        //SqlCommand cmd = new SqlCommand();
        //string connectionString = @"Data Source=DESKTOP-CCBV35A\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True";
        public Login()
        {
            InitializeComponent();
            //con.ConnectionString = @"Data Source=DESKTOP-CCBV35A\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True";
        }



        
    
        private void textboxUser_TextChanged(object sender, EventArgs e)
        {
            if (textboxUser.Text.Equals(@"Username"))
            {
                textboxUser.Text = "";
            }
        }

        private void textboxPassword_TextChanged(object sender, EventArgs e)
        {
            {
                if (textboxPassword.Text.Equals(@"Password"))
                {
                    textboxPassword.Text = "";
                }
            }
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (textboxUser.Text == "" && textboxPassword.Text == "")
            {
                MessageBox.Show("Please Fill Both Fields");
            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-CCBV35A\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True");
                string query = "select * from registration where UserName ='"+textboxUser.Text.Trim()+"' and Password ='"+textboxPassword.Text.Trim()+" ' ";
                SqlDataAdapter sda = new SqlDataAdapter(query , con);
                DataTable dtbl = new DataTable();
                sda.Fill(dtbl);
                //SqlCommand cmd = new SqlCommand("Select UserName= @UserName and Password = @Password from Registration");
                //con.Open();
                //cmd.Parameters.AddWithValue("@UserName" , textboxUser.Text);
                //cmd.Parameters.AddWithValue("@Password", textboxPassword.Text);
                //cmd.Connection = con;
                //cmd.CommandText = ("Select UserName= @UserName and Password = @Password from Registeration");
                //SqlDataReader dr = cmd.ExecuteReader();
                if (dtbl.Rows.Count == 1)
                {
                    //
                    //MessageBox.Show("LOGIN SUCCESSFUL");
                    Profile p = new Profile();
                    this.Hide();
                    p.Show();


                }
                else
                {
                    MessageBox.Show("INVALID LOGIN");
                }
                
            }
        }

        private void ButtonAccount_Click(object sender, EventArgs e)
        {
            Registration p = new Registration();
            p.Show();
            this.Hide();

        }

        private void newAccount_Click(object sender, EventArgs e)
        {

        }

        private void about_Click(object sender, EventArgs e)
        {
            About p = new About();
            p.Show();
            this.Hide();
        }

        private void hospitals_Click(object sender, EventArgs e)
        {
            BloodBanks p = new BloodBanks();
            p.Show();
            this.Hide();
        }

        private void donor_Click(object sender, EventArgs e)
        {
            DonorsList d = new DonorsList();
            d.Show();
            this.Hide();
        }

        private void feedback_Click(object sender, EventArgs e)
        {
            feedback d = new feedback();
            d.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}

