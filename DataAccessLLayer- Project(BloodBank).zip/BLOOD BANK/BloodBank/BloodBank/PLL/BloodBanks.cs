﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBank.PLL
{
    public partial class BloodBanks : Form
    {
        public BloodBanks()
        {
            InitializeComponent();
        }

        private void search_Click(object sender, EventArgs e)
        {
            
                string search = bunifuMaterialTextbox1.Text;
                                try
                {
                    StringBuilder querryaddress = new StringBuilder();
                    querryaddress.Append("http://maps.google.com/maps?q=");
                    if (search != string.Empty)
                    {
                        querryaddress.Append(search + "," + "+");
                    }
                    
                    webBrowser1.Navigate(querryaddress.ToString());
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString(), "Error");
                }
            }

        private void back_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }
    }
}
